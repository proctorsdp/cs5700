package cs5700.hw2.application.tools;

public enum  ObserverTypes {
    EMAIL,
    COMPARE,
    LEADERBOARD,
    PROGRESS
}
