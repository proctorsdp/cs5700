package cs5700.hw2.gui.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.AnchorPane;

public class ComparisonDisplayController {

    @FXML
    private TitledPane compareAthletesTitledPane;

    @FXML
    private AnchorPane anchorPane;

    @FXML
    private ListView<?> comparionListView;

}
